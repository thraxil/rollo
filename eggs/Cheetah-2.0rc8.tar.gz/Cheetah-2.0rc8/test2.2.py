from Cheetah.CheetahWrapper import CheetahWrapper
CheetahWrapper().main()
